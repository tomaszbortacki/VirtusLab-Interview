const api: string = "https://swapi.dev/api/";
export default api;
